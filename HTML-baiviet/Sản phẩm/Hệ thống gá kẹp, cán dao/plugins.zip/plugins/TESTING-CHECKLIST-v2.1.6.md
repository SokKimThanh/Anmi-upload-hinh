# ✅ Testing Checklist - Plugin v2.1.6

## 📋 Pre-Update Checklist

Trước khi update plugin lên v2.1.6:

- [ ] **Backup WordPress database**
- [ ] **Backup plugin folder** (`wp-content/plugins/anmi-product-style-injector/`)
- [ ] **Note current version:** Check in Plugins page (should be v2.1.5 or earlier)
- [ ] **Test on staging first** (if available)

---

## 🔄 Update Process

### Step 1: Deactivate Current Plugin
- [ ] Go to: `Plugins → Installed Plugins`
- [ ] Find: "An Mi Tools - Product Style Injector"
- [ ] Click: "Deactivate"
- [ ] Verify: Plugin status shows "Inactive"

### Step 2: Upload New Files
- [ ] Upload via FTP/cPanel:
  ```
  wp-content/plugins/anmi-product-style-injector/
    ├── anmi-product-style-injector.php  (REPLACE)
    └── js/
        └── grid-cleanup.js               (REPLACE)
  ```
- [ ] Verify file timestamps (should be today's date)

### Step 3: Activate Plugin
- [ ] Go to: `Plugins → Installed Plugins`
- [ ] Click: "Activate" on An Mi Product Style Injector
- [ ] Check version: Should show **v2.1.6**

### Step 4: Clear All Caches
- [ ] **Browser cache:** Ctrl+Shift+R (hard refresh)
- [ ] **WordPress cache:** Clear cache plugin (W3 Total Cache, WP Super Cache, etc.)
- [ ] **CDN cache:** Cloudflare Purge Everything (if using)
- [ ] **Server cache:** Clear OPcache/Redis (if applicable)

---

## 🧪 Test Cases

### Test 1: Existing Post - Verify `<p>` Tags Preserved

**Post to test:** 38-nt-tool-holder-system (or any product page)

1. **Frontend Check:**
   - [ ] Open post on frontend
   - [ ] Right-click → "View Page Source"
   - [ ] Search for: `<p>`
   - [ ] **Expected:** Find multiple `<p>` tags with product descriptions
   - [ ] **Expected:** Text inside `<p>` tags, not loose text

2. **Visual Check:**
   - [ ] Paragraphs have proper spacing
   - [ ] No text running together
   - [ ] Product descriptions readable

3. **Grid Layout Check:**
   - [ ] Feature grid displays correctly (3 columns on desktop)
   - [ ] Application grid displays correctly
   - [ ] No extra spacing between grid cards
   - [ ] Comment `<p>` tags removed (should not see comment text)

### Test 2: Edit Existing Post - Verify Editor Preserves `<p>`

**Post to edit:** Any product page

1. **Open in Editor:**
   - [ ] Go to: `Posts → Edit Post`
   - [ ] Switch to "Text" tab (Classic Editor) or Code view (Gutenberg)
   - [ ] **Verify:** See `<p>` tags around paragraphs

2. **Make Minor Edit:**
   - [ ] Change one word in a paragraph
   - [ ] Click "Update"
   - [ ] Verify: No "Page updated" error

3. **Check Frontend:**
   - [ ] Reload post on frontend
   - [ ] **Verify:** `<p>` tags still present in source
   - [ ] **Verify:** Grid layout still correct

### Test 3: New Post - Create from Scratch

**Create new product post:**

1. **Paste HTML with `<p>` tags:**
   ```html
   <section class="nt-test">
     <div class="section product-intro">
       <h2>Test Product</h2>
       <p>First paragraph with <strong>bold text</strong>.</p>
       <p>Second paragraph with normal text.</p>
     </div>
     
     <div class="feature-grid">
       <!-- Card 1: Feature -->
       <div class="feature-card">
         <h3>Feature 1</h3>
         <p>Description here.</p>
       </div>
     </div>
   </section>
   ```

2. **Save and Check:**
   - [ ] Click "Publish"
   - [ ] Open post on frontend
   - [ ] **Verify:** Both `<p>` tags in product-intro preserved
   - [ ] **Verify:** Grid layout displays correctly
   - [ ] **Verify:** Comment `<p>` removed from grid

### Test 4: JavaScript Console - Debug Mode

**Enable debug logging:**

1. **Open Browser Console:**
   - [ ] Press F12
   - [ ] Go to "Console" tab

2. **Enable Debug:**
   ```javascript
   window.anmiDebug = true;
   ```

3. **Reload Page:**
   - [ ] Press Ctrl+R
   - [ ] Watch console output

4. **Verify Output:**
   ```
   [An Mi Grid Cleanup] Summary:
     ❌ Removed: X comment/empty <p> in grids
     ✅ Preserved: Y content <p> in grids
     ✅ Preserved: Z <p> outside grids
   ```
   - [ ] **Check:** "Removed" count > 0 (if page has grid comments)
   - [ ] **Check:** "Preserved outside grids" count > 0
   - [ ] **Check:** No JavaScript errors

### Test 5: Mobile Responsive

**Test on mobile device or emulator:**

1. **Chrome DevTools:**
   - [ ] Press F12 → Toggle device toolbar
   - [ ] Select: iPhone SE / Galaxy S8

2. **Check Layout:**
   - [ ] Paragraphs readable (proper font size)
   - [ ] Grid converts to single column
   - [ ] Images scale correctly

3. **Verify `<p>` Tags:**
   - [ ] Open mobile view source (harder on mobile, can skip)
   - [ ] Visual check: Text has paragraph spacing

### Test 6: WordPress Editor Compatibility

**Test both editors:**

1. **Classic Editor:**
   - [ ] Switch to "Text" tab
   - [ ] See HTML with `<p>` tags
   - [ ] Edit and save
   - [ ] Verify: `<p>` preserved after save

2. **Gutenberg Editor:**
   - [ ] Open post in Gutenberg
   - [ ] Click: "⋮" → "Edit as HTML"
   - [ ] See HTML with `<p>` tags
   - [ ] Edit and save
   - [ ] Verify: `<p>` preserved after save

---

## 🐛 Known Issues to Watch For

### Issue 1: `<p>` Tags Still Missing

**If `<p>` tags disappear:**
- [ ] Check plugin version (must be v2.1.6)
- [ ] Clear all caches
- [ ] Check browser console for errors
- [ ] Enable WP_DEBUG and check error logs

**Debug Steps:**
```php
// In wp-config.php:
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);

// Check: /wp-content/debug.log
```

### Issue 2: Grid Layout Broken

**If grid shows extra spacing:**
- [ ] Verify grid-cleanup.js loaded (check Page Source)
- [ ] Enable debug mode: `window.anmiDebug = true;`
- [ ] Check console: Should show "Removed: X <p>"
- [ ] Verify CSS loaded: anmi-holder-products.css

### Issue 3: Images Not Clickable

**If image lightbox not working:**
- [ ] Check image-lightbox.js loaded
- [ ] Verify images have class `.bordered-img`
- [ ] Check console for JavaScript errors

---

## 📊 Success Criteria

All tests pass if:

- ✅ **`<p>` tags preserved** in all product descriptions
- ✅ **Grid layouts display correctly** (no extra spacing)
- ✅ **Comment `<p>` removed** from grid containers only
- ✅ **No JavaScript errors** in console
- ✅ **Mobile responsive** works correctly
- ✅ **Editor preserves `<p>`** when editing posts
- ✅ **No WordPress errors** in debug.log

---

## 📝 Test Results Log

**Date:** _______________  
**Tester:** _______________  
**WordPress Version:** _______________  
**PHP Version:** _______________

| Test Case | Status | Notes |
|-----------|--------|-------|
| Test 1: Existing Post | ☐ Pass ☐ Fail | |
| Test 2: Edit Post | ☐ Pass ☐ Fail | |
| Test 3: New Post | ☐ Pass ☐ Fail | |
| Test 4: Console Debug | ☐ Pass ☐ Fail | |
| Test 5: Mobile | ☐ Pass ☐ Fail | |
| Test 6: Editor | ☐ Pass ☐ Fail | |

**Overall Status:** ☐ ✅ All Tests Pass  ☐ ❌ Some Tests Fail

**Notes:**
```
[Write any issues or observations here]
```

---

## 🔄 Rollback Plan

**If tests fail and need to rollback:**

1. **Deactivate v2.1.6**
2. **Restore backup files:**
   - Old `anmi-product-style-injector.php` (v2.1.5)
   - Old `js/grid-cleanup.js` (v1.1.0)
3. **Activate plugin again**
4. **Clear all caches**
5. **Test one page to confirm rollback successful**
6. **Report issue** to development team with:
   - WordPress version
   - PHP version  
   - Error logs
   - Screenshots of issue

---

**Checklist Version:** 1.0  
**Last Updated:** November 2, 2025  
**For Plugin Version:** 2.1.6
